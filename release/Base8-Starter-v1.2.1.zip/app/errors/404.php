<?php

declare(strict_types=1);

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>404 Not Found</title>
</head>
<body>

<h1>404 Not Found</h1>

<p>The requested resource could not be found.</p>

</body>
</html>
