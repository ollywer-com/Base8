<?php

declare(strict_types=1);

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>400 Bad Request</title>
</head>
<body>

<h1>400 Bad Request</h1>

<p>The request could not be understood by the server.</p>

</body>
</html>
